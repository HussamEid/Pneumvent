
EN   Your CAD data on 29.03.2020 from Festo:

    Dear customer,
    
    attached please find the following file of our 2D/3D-CAD download portal powered by CADENAS:

	identification number: 197048 MHP1-M4H-2/2G-M3-TC 
    
    SE_3D_2019, 197048 MHP1-M4H-2/2G-M3-TC, 197048 MHP1-M4H-2_2G-M3-TC.par
    
    Please also check terms of use at:
    http://www.cadenas.de/terms-of-use-3d-cad-models
    
    Best regards

    Festo SE & Co. KG
    CAD Service
    design_tool@festo.com
    
