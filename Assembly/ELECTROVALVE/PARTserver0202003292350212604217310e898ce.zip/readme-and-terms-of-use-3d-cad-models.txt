
EN   Your CAD data on 29.03.2020 from Festo:

    Dear customer,
    
    attached please find the following file of our 2D/3D-CAD download portal powered by CADENAS:

	identification number: 197012 MHP1-M4H-3/2G-M3-TC 
    
    SE_3D_2019, 197012 MHP1-M4H-3/2G-M3-TC, 197012 MHP1-M4H-3_2G-M3-TC.par
    
    Please also check terms of use at:
    http://www.cadenas.de/terms-of-use-3d-cad-models
    
    Best regards

    Festo SE & Co. KG
    CAD Service
    design_tool@festo.com
    
