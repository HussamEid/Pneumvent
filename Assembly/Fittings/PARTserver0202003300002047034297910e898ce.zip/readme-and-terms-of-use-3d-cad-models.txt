
EN   Your CAD data on 30.03.2020 from Festo:

    Dear customer,
    
    attached please find the following file of our 2D/3D-CAD download portal powered by CADENAS:

	identification number: 153314 QSM-M3-4-I 
    
    SE_3D_2019, 153314 QSM-M3-4-I, 153314 QSM-M3-4-I.par
    
    Please also check terms of use at:
    http://www.cadenas.de/terms-of-use-3d-cad-models
    
    Best regards

    Festo SE & Co. KG
    CAD Service
    design_tool@festo.com
    
