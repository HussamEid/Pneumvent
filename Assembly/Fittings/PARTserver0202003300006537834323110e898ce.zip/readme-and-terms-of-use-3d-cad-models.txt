
EN   Your CAD data on 30.03.2020 from Festo:

    Dear customer,
    
    attached please find the following file of our 2D/3D-CAD download portal powered by CADENAS:

	identification number: 130610 QSY-8-4 
    
    SE_3D_2019, 130610 QSY-8-4, 130610 QSY-8-4.par
    
    Please also check terms of use at:
    http://www.cadenas.de/terms-of-use-3d-cad-models
    
    Best regards

    Festo SE & Co. KG
    CAD Service
    design_tool@festo.com
    
